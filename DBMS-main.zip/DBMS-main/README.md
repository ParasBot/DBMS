# DBMS
This is dbms praticals code library
